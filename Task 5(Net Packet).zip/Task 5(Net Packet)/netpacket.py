from scapy.all import sniff, IP, TCP, UDP # type: ignore

def packet_callback(packet):
    if IP in packet:
        ip_src = packet[IP].src
        ip_dst = packet[IP].dst
        proto = packet[IP].proto
        
        print(f"\nPacket: {ip_src} -> {ip_dst} | Protocol: {proto}", end="")

        if proto == 6 and TCP in packet:  # TCP
            print(f" | TCP {packet[TCP].sport} -> {packet[TCP].dport}", end="")
            print(f" | Payload: {bytes(packet[TCP].payload)[:20]}")
        elif proto == 17 and UDP in packet:  # UDP
            print(f" | UDP {packet[UDP].sport} -> {packet[UDP].dport}", end="")
            print(f" | Payload: {bytes(packet[UDP].payload)[:20]}")

def start_sniffer():
    print("Starting packet sniffer...")
    sniff(prn=packet_callback, store=0)

if __name__ == "__main__":
    start_sniffer()
